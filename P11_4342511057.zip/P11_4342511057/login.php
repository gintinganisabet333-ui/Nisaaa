<?php
session_start();
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = mysqli_real_escape_string($koneksi, $_POST['user']);
    $pass = mysqli_real_escape_string($koneksi, $_POST['pass']);

    $data = mysqli_query($koneksi, 
    "SELECT * FROM user WHERE username='$user' AND password='$pass'"
);


    if (mysqli_num_rows($data) > 0) {
        $row = mysqli_fetch_assoc($data);

        $_SESSION['username'] = $row['username'];
        header("Location: p11dashboard.php");
        exit();
    } else {
        $error = "Username atau password salah.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5 col-md-4">
        <h3 class="text-center">Login</h3>

        <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" name="user" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="pass" class="form-control" required>
            </div>

            <button class="btn btn-primary w-100">Login</button>

            <p class="text-center mt-2">
                Belum punya akun? <a href="register.php">Daftar</a>
            </p>
        </form>
    </div>
</body>
</html>
