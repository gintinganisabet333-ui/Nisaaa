<?php
include "koneksi.php";

$message = ""; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $user = mysqli_real_escape_string($koneksi, $_POST['username']);
    $pass = mysqli_real_escape_string($koneksi, $_POST['password']);

    // Role otomatis
    $role = "user";

    // Insert TANPA kolom id
    $sql = "INSERT INTO user (username, password, role) 
            VALUES ('$user', '$pass', '$role')";

    if (mysqli_query($koneksi, $sql)) {
        $message = "Akun berhasil dibuat!";
    } else {
        $message = "Terjadi error: " . mysqli_error($koneksi);
    }
}
?>



<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5 col-md-4">
    <h3 class="text-center">Register</h3>

    <?php if ($message != ""): ?>
        <div class="alert alert-info"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <button class="btn btn-success w-100">Daftar</button>

        <p class="text-center mt-2">
            Sudah punya akun? <a href="login.php">Login</a>
        </p>
    </form>
</div>
</body>
</html>
